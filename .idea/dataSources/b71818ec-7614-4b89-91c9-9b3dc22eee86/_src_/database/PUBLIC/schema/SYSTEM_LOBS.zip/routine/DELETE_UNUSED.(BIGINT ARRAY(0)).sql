CREATE PROCEDURE SYSTEM_LOBS.DELETE_UNUSED(IN L_IDS BIGINT ARRAY)
  SPECIFIC DELETE_UNUSED_10045
  LANGUAGE SQL
  NOT DETERMINISTIC
  MODIFIES SQL DATA
  NEW SAVEPOINT LEVEL BEGIN ATOMIC DECLARE TABLE LIVE_IDS(TEMP_ID INT );
  DECLARE TABLE TEMP_IDS(TEMP_ID INT );
  DECLARE TEMP_COUNT INT DEFAULT 1;
  WHILE TEMP_COUNT <= CARDINALITY(L_IDS) DO INSERT INTO MODULE.LIVE_IDS (TEMP_ID) VALUES L_IDS [TEMP_COUNT];
    SET TEMP_COUNT = TEMP_COUNT + 1;
  END WHILE;
  SET TEMP_COUNT = 0;
  REPEAT INSERT INTO MODULE.TEMP_IDS (TEMP_ID) SELECT LOB_IDS.LOB_ID
                                               FROM SYSTEM_LOBS.LOB_IDS
                                               WHERE LOB_USAGE_COUNT < 1 AND LOB_IDS.LOB_ID NOT IN (SELECT TEMP_ID
                                                                                                    FROM
                                                                                                      MODULE.LIVE_IDS)
                                               LIMIT 1000;
    INSERT INTO SYSTEM_LOBS.BLOCKS (BLOCK_ADDR, BLOCK_COUNT, TX_ID) (SELECT
                                                                       BLOCK_ADDR,
                                                                       BLOCK_COUNT,
                                                                       0
                                                                     FROM SYSTEM_LOBS.LOBS
                                                                     WHERE LOBS.LOB_ID IN (SELECT TEMP_ID
                                                                                           FROM MODULE.TEMP_IDS));
    DELETE FROM SYSTEM_LOBS.LOBS
    WHERE LOBS.LOB_ID IN (SELECT TEMP_ID
                          FROM MODULE.TEMP_IDS);
    DELETE FROM SYSTEM_LOBS.PARTS
    WHERE LOB_ID IN (SELECT TEMP_ID
                     FROM MODULE.TEMP_IDS);
    DELETE FROM SYSTEM_LOBS.LOB_IDS
    WHERE LOB_IDS.LOB_ID IN (SELECT TEMP_ID
                             FROM MODULE.TEMP_IDS);
    GET DIAGNOSTICS TEMP_COUNT = ROW_COUNT;
    DELETE FROM MODULE.TEMP_IDS;
  UNTIL TEMP_COUNT < 1000 END REPEAT;
END;